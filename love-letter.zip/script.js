
let captions = [
    "প্রিয় নিহা,, তুমি আমার পৃথিবী 💖",
    "প্রিয় নিহা,, তোমার হাসিই আমার সুখ 😊💞",
    "প্রিয় নিহা,, তুমি আমার স্বপ্নের রাজকন্যা 👸💖",
    "প্রিয় নিহা,, তোমার ভালোবাসাই আমার শক্তি 💪💓",
    "প্রিয় নিহা,, তুমি আমার সকাল-সন্ধ্যা 🌅🌙",
    "প্রিয় নিহা,, তোমার সাথে কাটানো প্রতিটি মুহূর্ত অমূল্য 🕰️❤️",
    "প্রিয় নিহা,, তুমি আমার একমাত্র ভালোবাসা ❤️🔥",
    "প্রিয় নিহা,, তুমি আমার জীবনের সবচেয়ে বড় আশীর্বাদ 🙏💖"
];

let index = 0;
const bgMusic = document.getElementById("bgMusic");

function changeText() {
    let caption = document.getElementById("captionText");
    caption.innerText = captions[index % captions.length];
    caption.classList.add("show");

    setTimeout(() => caption.classList.remove("show"), 1000);

    if(bgMusic.paused) bgMusic.play();
    index++;
}

let canvas = document.getElementById("particles");
let ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let particles = [];

class Particle {
    constructor() {
        this.x = Math.random() * canvas.width;
        this.y = Math.random() * canvas.height;
        this.size = Math.random() * 3 + 1;
        this.speedX = Math.random() * 3 - 1.5;
        this.speedY = Math.random() * 3 - 1.5;
        this.color = `hsl(${Math.random() * 360}, 100%, 50%)`;
    }
    update() {
        this.x += this.speedX;
        this.y += this.speedY;
        if (this.size > 0.2) this.size -= 0.02;
    }
    draw() {
        ctx.fillStyle = this.color;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI*2);
        ctx.fill();
    }
}

function createParticles() {
    let particleCount = window.innerWidth < 768 ? 50 : 100;
    for(let i=0; i<particleCount; i++) particles.push(new Particle());
}

function animateParticles() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for(let i=0; i<particles.length; i++){
        particles[i].update();
        particles[i].draw();
        if(particles[i].size <= 0.2) particles[i] = new Particle();
    }
    requestAnimationFrame(animateParticles);
}

createParticles();
animateParticles();

window.addEventListener("resize", function(){
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
});
